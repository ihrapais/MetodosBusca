﻿using System;
using System.Collections.Generic;

namespace LabirintoSimples
{
    // Tipos de célula do labirinto
    public enum TipoCelula { Livre, Obstaculo, Entrada, Saida }

    // Classe para o labirinto
    public class Labirinto
    {
        public int Tamanho { get; }
        public TipoCelula[,] mapa;
        public (int linha, int coluna) entrada1;
        public (int linha, int coluna) entrada2;
        public (int linha, int coluna) saida;

        public Labirinto(int tamanho)
        {
            Tamanho = tamanho;
            mapa = new TipoCelula[tamanho, tamanho];
            // Tudo começa como livre
            for (int i = 0; i < tamanho; i++)
                for (int j = 0; j < tamanho; j++)
                    mapa[i, j] = TipoCelula.Livre;
        }

        public void ColocarObstaculo(int linha, int coluna)
        {
            if (EstaDentro(linha, coluna) && mapa[linha, coluna] == TipoCelula.Livre)
                mapa[linha, coluna] = TipoCelula.Obstaculo;
        }

        public void ColocarEntrada(int linha, int coluna, int numeroEntrada)
        {
            if (EstaDentro(linha, coluna) && mapa[linha, coluna] == TipoCelula.Livre)
            {
                mapa[linha, coluna] = TipoCelula.Entrada;
                if (numeroEntrada == 1)
                    entrada1 = (linha, coluna);
                else if (numeroEntrada == 2)
                    entrada2 = (linha, coluna);
            }
        }

        public void ColocarSaida(int linha, int coluna)
        {
            if (EstaDentro(linha, coluna) && mapa[linha, coluna] == TipoCelula.Livre)
            {
                mapa[linha, coluna] = TipoCelula.Saida;
                saida = (linha, coluna);
            }
        }

        public bool EstaDentro(int linha, int coluna)
        {
            return linha >= 0 && linha < Tamanho && coluna >= 0 && coluna < Tamanho;
        }

        public bool EstaLivre(int linha, int coluna)
        {
            return EstaDentro(linha, coluna) && (mapa[linha, coluna] == TipoCelula.Livre || mapa[linha, coluna] == TipoCelula.Saida);
        }
    }

    // Classe para um ponto no caminho
    public class Ponto
    {
        public int linha;
        public int coluna;
        public Ponto anterior;

        public Ponto(int l, int c, Ponto ant = null)
        {
            linha = l;
            coluna = c;
            anterior = ant;
        }
    }

    // Classe com os métodos de busca
    public static class Busca
    {
        // Busca em Largura (BFS) - simples, usa lista como fila
        public static List<Ponto> BuscaLargura(Labirinto lab, (int linha, int coluna) inicio)
        {
            int[] direcoesLinha = { -1, 1, 0, 0 }; // cima, baixo, esquerda, direita
            int[] direcoesColuna = { 0, 0, -1, 1 };
            bool[,] visitado = new bool[lab.Tamanho, lab.Tamanho];
            List<Ponto> fila = new List<Ponto>();
            fila.Add(new Ponto(inicio.linha, inicio.coluna));
            visitado[inicio.linha, inicio.coluna] = true;

            while (fila.Count > 0)
            {
                Ponto atual = fila[0];
                fila.RemoveAt(0); // Remove o primeiro da fila

                if (atual.linha == lab.saida.linha && atual.coluna == lab.saida.coluna)
                    return ConstruirCaminho(atual);

                for (int i = 0; i < 4; i++)
                {
                    int novaLinha = atual.linha + direcoesLinha[i];
                    int novaColuna = atual.coluna + direcoesColuna[i];
                    if (lab.EstaLivre(novaLinha, novaColuna) && !visitado[novaLinha, novaColuna])
                    {
                        visitado[novaLinha, novaColuna] = true;
                        fila.Add(new Ponto(novaLinha, novaColuna, atual));
                    }
                }
            }
            return null; // Sem caminho
        }

        // Busca em Profundidade (DFS) - simples, usa lista como pilha
        public static List<Ponto> BuscaProfundidade(Labirinto lab, (int linha, int coluna) inicio)
        {
            int[] direcoesLinha = { -1, 1, 0, 0 }; // cima, baixo, esquerda, direita
            int[] direcoesColuna = { 0, 0, -1, 1 };
            bool[,] visitado = new bool[lab.Tamanho, lab.Tamanho];
            List<Ponto> pilha = new List<Ponto>();
            pilha.Add(new Ponto(inicio.linha, inicio.coluna));
            visitado[inicio.linha, inicio.coluna] = true;

            while (pilha.Count > 0)
            {
                Ponto atual = pilha[pilha.Count - 1]; // Pega o último da pilha
                pilha.RemoveAt(pilha.Count - 1); // Remove o último

                if (atual.linha == lab.saida.linha && atual.coluna == lab.saida.coluna)
                    return ConstruirCaminho(atual);

                for (int i = 0; i < 4; i++)
                {
                    int novaLinha = atual.linha + direcoesLinha[i];
                    int novaColuna = atual.coluna + direcoesColuna[i];
                    if (lab.EstaLivre(novaLinha, novaColuna) && !visitado[novaLinha, novaColuna])
                    {
                        visitado[novaLinha, novaColuna] = true;
                        pilha.Add(new Ponto(novaLinha, novaColuna, atual));
                    }
                }
            }
            return null; // Sem caminho
        }

        // Constrói o caminho do ponto final até o início
        private static List<Ponto> ConstruirCaminho(Ponto final)
        {
            List<Ponto> caminho = new List<Ponto>();
            Ponto atual = final;
            while (atual != null)
            {
                caminho.Add(atual);
                atual = atual.anterior;
            }
            caminho.Reverse();
            return caminho;
        }
    }

    class Programa
    {
        static void MostrarCaminho(List<Ponto> caminho, string metodo)
        {
            Console.WriteLine($"\nCaminho com {metodo}:");
            if (caminho == null)
            {
                Console.WriteLine("Nenhum caminho encontrado.");
                return;
            }
            foreach (var ponto in caminho)
            {
                Console.Write($"({ponto.linha},{ponto.coluna}) ");
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            Random aleatorio = new Random();

            // Pede entrada do usuário
            Console.Write("Digite o tamanho do labirinto (N): ");
            int tamanho = int.Parse(Console.ReadLine());
            Console.Write("Digite o número de obstáculos (M): ");
            int obstaculos = int.Parse(Console.ReadLine());

            Labirinto lab = new Labirinto(tamanho);

            // Sorteia entrada 1, entrada 2 e saída
            int linha1, coluna1, linha2, coluna2, linhaSaida, colunaSaida;
            do
            {
                linha1 = aleatorio.Next(tamanho);
                coluna1 = aleatorio.Next(tamanho);
            } while (lab.mapa[linha1, coluna1] != TipoCelula.Livre);
            lab.ColocarEntrada(linha1, coluna1, 1);

            do
            {
                linha2 = aleatorio.Next(tamanho);
                coluna2 = aleatorio.Next(tamanho);
            } while (lab.mapa[linha2, coluna2] != TipoCelula.Livre || (linha2 == linha1 && coluna2 == coluna1));
            lab.ColocarEntrada(linha2, coluna2, 2);

            do
            {
                linhaSaida = aleatorio.Next(tamanho);
                colunaSaida = aleatorio.Next(tamanho);
            } while (lab.mapa[linhaSaida, colunaSaida] != TipoCelula.Livre || (linhaSaida == linha1 && colunaSaida == coluna1) || (linhaSaida == linha2 && colunaSaida == coluna2));
            lab.ColocarSaida(linhaSaida, colunaSaida);

            // Coloca obstáculos aleatórios
            for (int i = 0; i < obstaculos; i++)
            {
                int linha, coluna;
                do
                {
                    linha = aleatorio.Next(tamanho);
                    coluna = aleatorio.Next(tamanho);
                } while (lab.mapa[linha, coluna] != TipoCelula.Livre);
                lab.ColocarObstaculo(linha, coluna);
            }

            // Mostra o labirinto
            Console.WriteLine("\nLabirinto:");
            for (int i = 0; i < tamanho; i++)
            {
                for (int j = 0; j < tamanho; j++)
                {
                    char simbolo;
                    if (lab.mapa[i, j] == TipoCelula.Saida)
                        simbolo = 'S';
                    else if (lab.mapa[i, j] == TipoCelula.Entrada)
                        simbolo = (i == lab.entrada1.linha && j == lab.entrada1.coluna) ? '1' : '2';
                    else if (lab.mapa[i, j] == TipoCelula.Obstaculo)
                        simbolo = 'X';
                    else
                        simbolo = '_';
                    Console.Write(simbolo + " ");
                }
                Console.WriteLine();
            }

            // Faz as buscas
            var caminhoLargura = Busca.BuscaLargura(lab, lab.entrada1);
            MostrarCaminho(caminhoLargura, "Largura (Entrada 1)");

            var caminhoProfundidade = Busca.BuscaProfundidade(lab, lab.entrada2);
            MostrarCaminho(caminhoProfundidade, "Profundidade (Entrada 2)");

            // Compara os caminhos
            if (caminhoLargura != null && caminhoProfundidade != null)
            {
                Console.WriteLine($"\nTamanho do caminho Largura: {caminhoLargura.Count}");
                Console.WriteLine($"Tamanho do caminho Profundidade: {caminhoProfundidade.Count}");
            }
            else
            {
                Console.WriteLine("\nUm ou ambos os caminhos não foram encontrados.");
            }
        }
    }
}